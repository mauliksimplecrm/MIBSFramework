//
//  Reachability.h
//  Reachability
//
//  Created by Yuki Nagai on 11/2/15.
//  Copyright © 2015 Ashley Mills. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Reachability.
FOUNDATION_EXPORT double ReachabilityVersionNumber;

//! Project version string for Reachability.
FOUNDATION_EXPORT const unsigned char ReachabilityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Reachability/PublicHeader.h>
